/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.calculardoraentornos;

/**
 *
 * @author usuario
 */
public class Calc {
    
     public static int suma(int num1, int num2){
        int res=num1+num2;
        return res;
    }
    public static int resta(int num1, int num2){
        int res=num1-num2;
        return res;
    }
    public static int mul(int num1, int num2){
        int res=num1*num2;
        return res;
    }
    public static int div(int num1, int num2){
        int res=num1/num2;
        return res;
    }
}
